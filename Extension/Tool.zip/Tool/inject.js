(function() {
  // 1. Ép WebGL giữ lại bộ đệm hình ảnh
  const originalGetContext = HTMLCanvasElement.prototype.getContext;
  HTMLCanvasElement.prototype.getContext = function(type, attributes) {
    if (type === 'webgl' || type === 'webgl2' || type === 'experimental-webgl') {
      attributes = Object.assign({}, attributes, { preserveDrawingBuffer: true });
    }
    return originalGetContext.call(this, type, attributes);
  };

  // 2. Lắng nghe lệnh yêu cầu lấy ảnh Canvas từ content.js
  window.addEventListener('message', function(event) {
    // Chỉ xử lý khi có yêu cầu lấy ảnh
    if (event.data && event.data.type === 'GET_CANVAS_IMAGE') {
      
      // Tìm thẻ canvas lớn nhất
      const canvases = Array.from(document.querySelectorAll('canvas'));
      let targetCanvas = null;
      let maxArea = 0;

      canvases.forEach(canvas => {
        const area = canvas.width * canvas.height;
        if (area > maxArea && canvas.width > 50 && canvas.height > 50) {
          maxArea = area;
          targetCanvas = canvas;
        }
      });

      if (targetCanvas) {
        try {
          // Lấy dữ liệu ảnh và gửi ngược lại cho content.js
          const dataUrl = targetCanvas.toDataURL('image/png');
          const rect = targetCanvas.getBoundingClientRect(); // Lấy vị trí của canvas
          
          window.postMessage({
            type: 'CANVAS_IMAGE_RESULT',
            dataUrl: dataUrl,
            width: rect.width,
            height: rect.height,
            top: rect.top,
            left: rect.left
          }, '*');
        } catch (e) {
          window.postMessage({ type: 'CANVAS_IMAGE_RESULT', error: e.message }, '*');
        }
      } else {
        window.postMessage({ type: 'CANVAS_IMAGE_RESULT', error: 'No canvas found' }, '*');
      }
    }
  });
})();
// Danh sách model ưu tiên (từ mạnh nhất đến nhẹ nhất)
const MODEL_LIST = [
  'gemini-3.8-flash',
  'gemini-3.6-flash',
  'gemini-3.5-flash-lite',
  'gemini-3.1-flash-lite'
];

async function askGemini(apiKey, base64Image, textPrompt, preferredModel) {
  // Tạo danh sách thử nghiệm: Ưu tiên model người dùng chọn, sau đó đến các model còn lại
  let modelsToTry = [preferredModel];
  MODEL_LIST.forEach(m => {
    if (m !== preferredModel) modelsToTry.push(m);
  });

  let lastError = null;

  for (let i = 0; i < modelsToTry.length; i++) {
    const currentModel = modelsToTry[i];
    const url = `https://generativelanguage.googleapis.com/v1beta/models/${currentModel}:generateContent?key=${apiKey}`;

    const body = {
      contents: [{
        parts: [
          { text: textPrompt || "Hãy mô tả và giải thích nội dung của hình ảnh chụp màn hình này một cách ngắn gọn và hữu ích." },
          { inline_data: { mime_type: "image/jpeg", data: base64Image } }
        ]
      }]
    };

    try {
      const response = await fetch(url, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(body)
      });

      if (!response.ok) {
        const err = await response.json().catch(() => ({}));
        const errMsg = err?.error?.message || response.statusText;
        
        // 429: Quá tải / Hết hạn mức, 503: Server bận, 500: Lỗi server
        if (response.status === 429 || response.status === 503 || response.status === 500) {
          console.warn(`[Fallback] Model ${currentModel} quá tải (${response.status}). Chuyển sang model khác...`);
          lastError = new Error(`Quá tải ở ${currentModel}`);
          continue; // Thử model tiếp theo
        }
        
        // Lỗi do API key hoặc request sai thì dừng luôn
        throw new Error(`Lỗi ${currentModel}: ${errMsg}`);
      }

      const data = await response.json();
      const answer = data.candidates?.[0]?.content?.parts?.[0]?.text;
      if (answer) {
        // Ghi chú lại nếu phải dùng model fallback
        const usedFallback = currentModel !== preferredModel;
        return { answer, modelUsed: currentModel, usedFallback };
      }

    } catch (error) {
      lastError = error;
      console.warn(`[Fallback] Lỗi mạng hoặc API ở ${currentModel}:`, error);
      // Lỗi mạng cũng thử model tiếp theo
    }
  }

  // Nếu tất cả đều thất bại
  throw new Error(`Không thể kết nối tới bất kỳ model nào. Chi tiết: ${lastError?.message || 'Unknown'}`);
}

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === 'askGemini') {
    (async () => {
      try {
        if (!request.apiKey) throw new Error('Chưa có API key.');
        if (!request.base64Image) throw new Error('Thiếu dữ liệu ảnh.');
        
        const result = await askGemini(request.apiKey, request.base64Image, request.prompt, request.model);
        sendResponse(result);
      } catch (e) {
        sendResponse({ error: e.message });
      }
    })();
    return true; 
  }
});

chrome.action.onClicked.addListener((tab) => {
  chrome.tabs.sendMessage(tab.id, { action: "openPanel" }).catch(() => {});
});
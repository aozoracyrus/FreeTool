(function () {
  if (window.__geminiScreenInjected) return;
  window.__geminiScreenInjected = true;

  const script = document.createElement('script');
  script.src = chrome.runtime.getURL('inject.js');
  (document.head || document.documentElement).appendChild(script);
  script.onload = () => script.remove();

  let isProcessing = false;   
  let isDragging = false;     
  let currentBase64 = ""; 
  const DEFAULT_AVATAR_URL = chrome.runtime.getURL('avatar.png');

  const DEFAULT_QUICK_REPLIES = [
    "Đáp án câu này là gì?",
    "Tên này có nghĩa là gì?",
    "Dịch đoạn văn bản này sang tiếng Việt"
  ];

  // ==========================================
  // GIAO DIỆN (SHADOW DOM)
  // ==========================================
  const host = document.createElement('div');
  host.id = '__gemini_screen_host';
  host.style.cssText = 'position:fixed;z-index:2147483647;top:0;left:0;width:0;height:0;';
  
  const initUI = () => {
    (document.body || document.documentElement).appendChild(host);
    const shadow = host.attachShadow({ mode: 'open' });
    
    shadow.innerHTML = `
      <style>
        :host { all: initial; }
        
        /* CỤM NÚT NỔI (FABs) */
        .fab-group {
          position: fixed; bottom: 20px; right: 20px;
          display: flex; flex-direction: column; gap: 12px; align-items: flex-end;
          z-index: 10; 
        }
        
        .btn-toggle {
          width: 46px; height: 46px; border-radius: 50%;
          background: #fff; color: #4285f4; border: 2px solid #4285f4;
          box-shadow: 0 4px 10px rgba(0,0,0,.2);
          display: flex; align-items: center; justify-content: center;
          font-size: 22px; cursor: pointer; touch-action: none;
        }
        
        .btn-capture {
          width: 60px; height: 60px; border-radius: 50%;
          background-size: cover; background-position: center;
          box-shadow: 0 4px 14px rgba(0,0,0,.3); cursor: pointer; 
          touch-action: none; border: 3px solid #fff;
        }

        /* BẢNG ĐIỀU KHIỂN */
        .panel {
          position: fixed; bottom: 90px; right: 20px;
          width: 350px; max-width: calc(100vw - 40px); 
          height: 75vh; max-height: 600px;
          background: #fff; border-radius: 12px;
          box-shadow: 0 8px 32px rgba(0,0,0,.3);
          display: none; flex-direction: column;
          font-family: system-ui, sans-serif; font-size: 14px; 
          overflow: hidden; border: 1px solid #ddd;
          z-index: 20; 
        }
        .panel.show { display: flex; }
        
        .header {
          padding: 10px 12px; background: linear-gradient(135deg, #4285f4, #34a853);
          color: #fff; display: flex; justify-content: space-between;
          align-items: center; font-weight: 600; flex-shrink: 0;
        }
        .header button { background: rgba(255,255,255,.25); color: #fff; border: none; width: 28px; height: 28px; border-radius: 6px; cursor: pointer; font-size: 14px; }
        
        /* CÀI ĐẶT */
        .settings { padding: 12px; display: none; border-bottom: 1px solid #eee; background: #fafafa; overflow-y: auto; flex-shrink: 0; max-height: 50%; }
        .settings.show { display: block; }
        .settings label { display: block; margin-bottom: 6px; font-size: 12px; font-weight: 600; color: #444; }
        .input-row { display: flex; gap: 6px; margin-bottom: 12px; }
        input[type="password"] { flex: 1; padding: 8px; border: 1px solid #ddd; font-size: 14px; border-radius: 6px; }
        select { width: 100%; padding: 8px; border: 1px solid #ddd; font-size: 13px; border-radius: 6px; margin-bottom: 12px; }
        textarea { width: 100%; height: 60px; padding: 8px; border: 1px solid #ddd; font-size: 13px; border-radius: 6px; margin-bottom: 12px; resize: vertical; box-sizing: border-box; }
        .save-btn { padding: 8px 14px; background: #34a853; color: #fff; border: none; border-radius: 6px; cursor: pointer; font-weight: 600; width: 100%; }

        /* KHU VỰC CHAT & TRẢ LỜI */
        .status { font-size: 12px; color: #666; padding: 6px 12px; border-bottom: 1px solid #eee; background: #fdfdfd; flex-shrink: 0; }
        .status.error { color: #d93025; background: #fce8e6; }
        .status.success { color: #188038; background: #e6f4ea; }
        
        .body { padding: 12px; overflow-y: auto; display: flex; flex-direction: column; gap: 10px; flex-grow: 1; }
        .msg { padding: 8px 12px; border-radius: 8px; max-width: 90%; line-height: 1.4; word-wrap: break-word; }
        .msg.user { background: #e3f2fd; color: #000; align-self: flex-end; border-bottom-right-radius: 2px; }
        .msg.ai { background: #f1f3f4; color: #000; align-self: flex-start; border-bottom-left-radius: 2px; white-space: pre-wrap; }
        .preview { max-width: 100%; max-height: 120px; display: block; margin: 0 auto 5px; border-radius: 6px; border: 1px solid #ddd; align-self: center; }

        /* THANH NHẬP & QUICK REPLIES */
        .bottom-area { flex-shrink: 0; background: #fff; border-top: 1px solid #eee; display: flex; flex-direction: column; }
        
        .quick-replies { display: flex; gap: 6px; padding: 8px 12px; overflow-x: auto; white-space: nowrap; scrollbar-width: none; }
        .quick-replies::-webkit-scrollbar { display: none; }
        .chip { background: #f1f3f4; border: 1px solid #dadce0; padding: 6px 12px; border-radius: 16px; font-size: 12px; cursor: pointer; color: #3c4043; transition: 0.2s; }
        .chip:hover { background: #e8f0fe; border-color: #1a73e8; color: #1a73e8; }
        
        .chat-input { padding: 8px 12px; display: flex; gap: 6px; background: #fff; }
        .chat-input input { flex: 1; padding: 10px 14px; border: 1px solid #ddd; border-radius: 20px; outline: none; font-size: 14px; }
        .chat-input button { background: #4285f4; color: #fff; border: none; width: 40px; height: 40px; border-radius: 50%; cursor: pointer; display: flex; align-items: center; justify-content: center; font-size: 16px; flex-shrink: 0; }
        
        .footer { text-align: center; padding: 4px; font-size: 10px; color: #999; background: #fafafa; border-top: 1px solid #eee; flex-shrink: 0; }
      </style>

      <div class="fab-group" id="fabGroup">
        <button class="btn-toggle" id="toggleBtn" title="Mở/Đóng Chat">💬</button>
        <button class="btn-capture" id="captureBtn" title="Chụp màn hình"></button>
      </div>

      <div class="panel" id="panel">
        <div class="header">
          <div>✨ Gemini Screen</div>
          <div style="display:flex;gap:6px">
            <button id="settingsBtn">⚙️</button>
            <button id="closeBtn">×</button>
          </div>
        </div>
        
        <div class="settings" id="settings">
          <label>Gemini API Key</label>
          <div class="input-row"><input type="password" id="apiKeyInput" placeholder="Dán API key..." /><button class="save-btn" style="width:auto;" id="saveKeyBtn">Lưu</button></div>
          
          <label>Model AI (Tự động Fallback)</label>
          <select id="modelSelect">
            <option value="gemini-3.8-flash">Gemini 3.8 Flash</option>
            <option value="gemini-3.6-flash">Gemini 3.6 Flash</option>
            <option value="gemini-3.5-flash-lite">Gemini 3.5 Flash-Lite</option>
            <option value="gemini-3.1-flash-lite">Gemini 3.1 Flash-Lite</option>
          </select>

          <label>Trả lời nhanh (Mỗi câu 1 dòng)</label>
          <textarea id="quickRepliesInput" placeholder="Đáp án là gì?&#10;Dịch đoạn này..."></textarea>
        </div>

        <div class="status" id="status">Sẵn sàng</div>
        
        <div class="body" id="body">
          <!-- Nội dung chat -->
        </div>
        
        <div class="bottom-area">
          <div class="quick-replies" id="quickReplies"></div>
          <div class="chat-input">
            <input type="text" id="chatInput" placeholder="Hỏi thêm về bức ảnh..." />
            <button id="sendBtn">➤</button>
          </div>
        </div>

        <div class="footer">v12.2 • Made by Minh Quân ❤️</div>
      </div>
    `;

    const $ = id => shadow.getElementById(id);
    const fabGroup = $('fabGroup'), toggleBtn = $('toggleBtn'), captureBtn = $('captureBtn');
    const panel = $('panel'), settingsDiv = $('settings');
    const statusEl = $('status'), bodyEl = $('body');
    const apiKeyInput = $('apiKeyInput'), saveKeyBtn = $('saveKeyBtn');
    const settingsBtn = $('settingsBtn'), closeBtn = $('closeBtn');
    const modelSelect = $('modelSelect'), quickRepliesInput = $('quickRepliesInput');
    const quickRepliesDiv = $('quickReplies'), chatInput = $('chatInput'), sendBtn = $('sendBtn');

    captureBtn.style.backgroundImage = `url("${DEFAULT_AVATAR_URL}")`;

    // ==========================================
    // HÀM TIỆN ÍCH & CÀI ĐẶT
    // ==========================================
    function setStatus(text, cls) { statusEl.textContent = text; statusEl.className = 'status ' + (cls || ''); }
    async function getApiKey() { const { geminiApiKey } = await chrome.storage.local.get(['geminiApiKey']); return geminiApiKey || ''; }

    async function loadSettings() {
      const data = await chrome.storage.local.get(['geminiApiKey', 'geminiModel', 'quickReplies']);
      if (data.geminiApiKey) apiKeyInput.value = data.geminiApiKey;
      
      // Gán Model đã lưu
      if (data.geminiModel) {
        modelSelect.value = data.geminiModel;
      }
      
      const qrs = data.quickReplies || DEFAULT_QUICK_REPLIES;
      quickRepliesInput.value = qrs.join('\n');
      renderQuickReplies(qrs);
    }

    function renderQuickReplies(list) {
      quickRepliesDiv.innerHTML = '';
      list.forEach(text => {
        if (!text.trim()) return;
        const chip = document.createElement('button');
        chip.className = 'chip';
        chip.textContent = text;
        chip.onclick = () => {
          if (!currentBase64) return setStatus('⚠ Hãy chụp ảnh trước!', 'error');
          sendQuestion(text);
        };
        quickRepliesDiv.appendChild(chip);
      });
    }

    // ==========================================
    // SỰ KIỆN LƯU TỰ ĐỘNG KHI ĐỔI MODEL
    // ==========================================
    modelSelect.addEventListener('change', async () => {
      await chrome.storage.local.set({ geminiModel: modelSelect.value });
      setStatus(`✓ Đã lưu Model: ${modelSelect.value}`, 'success');
      setTimeout(() => setStatus('Sẵn sàng'), 2000);
    });

    // Mở/Đóng bảng
    toggleBtn.addEventListener('click', () => panel.classList.toggle('show'));
    closeBtn.addEventListener('click', () => panel.classList.remove('show'));
    settingsBtn.addEventListener('click', () => settingsDiv.classList.toggle('show'));
    
    // Nút Lưu (Dành cho API Key và Quick Replies)
    saveKeyBtn.addEventListener('click', async () => {
      const key = apiKeyInput.value.trim();
      if (key) await chrome.storage.local.set({ geminiApiKey: key });
      await chrome.storage.local.set({ geminiModel: modelSelect.value }); // Lưu luôn model cho chắc
      
      const qrs = quickRepliesInput.value.split('\n').map(s => s.trim()).filter(Boolean);
      await chrome.storage.local.set({ quickReplies: qrs });
      renderQuickReplies(qrs);
      
      setStatus('✓ Đã lưu cài đặt', 'success');
      setTimeout(() => setStatus('Sẵn sàng'), 2000);
    });

    // ==========================================
    // KÉO THẢ CỤM NÚT
    // ==========================================
    let dragStartX, dragStartY, startRight, startBottom;
    fabGroup.addEventListener('pointerdown', (e) => {
      isDragging = false; dragStartX = e.clientX; dragStartY = e.clientY;
      const rect = fabGroup.getBoundingClientRect();
      startRight = window.innerWidth - rect.right; startBottom = window.innerHeight - rect.bottom;
      
      const onMove = (ev) => {
        if (Math.abs(ev.clientX - dragStartX) > 5 || Math.abs(ev.clientY - dragStartY) > 5) {
          isDragging = true;
          const newRight = Math.max(8, Math.min(window.innerWidth - 80, startRight - (ev.clientX - dragStartX)));
          const newBottom = Math.max(8, Math.min(window.innerHeight - 120, startBottom - (ev.clientY - dragStartY)));
          
          fabGroup.style.right = newRight + 'px'; 
          fabGroup.style.bottom = newBottom + 'px';
          panel.style.right = newRight + 'px'; 
          panel.style.bottom = (newBottom + 90) + 'px';
        }
      };
      const onUp = () => fabGroup.removeEventListener('pointermove', onMove);
      fabGroup.addEventListener('pointermove', onMove); 
      fabGroup.addEventListener('pointerup', onUp, { once: true });
    });

    // ==========================================
    // CHỤP ẢNH (HTML2CANVAS + INJECT)
    // ==========================================
    async function capturePage() {
      setStatus('Đang xử lý hình ảnh...', '');
      host.style.display = 'none'; 
      
      const canvasData = await new Promise((resolve) => {
        const handler = (e) => {
          if (e.data && e.data.type === 'CANVAS_IMAGE_RESULT') {
            window.removeEventListener('message', handler);
            resolve(e.data);
          }
        };
        window.addEventListener('message', handler);
        window.postMessage({ type: 'GET_CANVAS_IMAGE' }, '*');
        setTimeout(() => { window.removeEventListener('message', handler); resolve(null); }, 1000);
      });

      let tempImg = null;
      if (canvasData && canvasData.dataUrl) {
        tempImg = document.createElement('img');
        tempImg.src = canvasData.dataUrl;
        Object.assign(tempImg.style, {
          position: 'absolute', top: canvasData.top + 'px', left: canvasData.left + 'px',
          width: canvasData.width + 'px', height: canvasData.height + 'px', zIndex: '999999'
        });
        document.body.appendChild(tempImg);
      }

      await new Promise(r => setTimeout(r, 150));

      try {
        const canvas = await html2canvas(document.body, {
          useCORS: true, allowTaint: true, scale: window.devicePixelRatio || 1,
          width: window.innerWidth, height: window.innerHeight
        });

        const MAX = 1568;
        let finalCanvas = canvas;
        if (canvas.width > MAX || canvas.height > MAX) {
          const ratio = Math.min(MAX / canvas.width, MAX / canvas.height);
          const tmp = document.createElement('canvas');
          tmp.width = Math.round(canvas.width * ratio); tmp.height = Math.round(canvas.height * ratio);
          tmp.getContext('2d').drawImage(canvas, 0, 0, tmp.width, tmp.height);
          finalCanvas = tmp;
        }
        return finalCanvas.toDataURL('image/jpeg', 0.85);
      } finally {
        host.style.display = ''; 
        if (tempImg) tempImg.remove(); 
      }
    }

    // ==========================================
    // GỬI CÂU HỎI
    // ==========================================
    async function sendQuestion(questionText) {
      const key = await getApiKey();
      if (!key) { settingsDiv.classList.add('show'); return setStatus('⚠ Chưa có API key.', 'error'); }

      isProcessing = true; captureBtn.style.opacity = '0.5'; sendBtn.disabled = true;
      
      if (questionText) {
        const userMsg = document.createElement('div');
        userMsg.className = 'msg user';
        userMsg.textContent = questionText;
        bodyEl.appendChild(userMsg);
      }
      bodyEl.scrollTop = bodyEl.scrollHeight;

      const loadingMsg = document.createElement('div');
      loadingMsg.className = 'msg ai';
      loadingMsg.textContent = '⏳ Đang suy nghĩ...';
      bodyEl.appendChild(loadingMsg);
      bodyEl.scrollTop = bodyEl.scrollHeight;

      setStatus('Đang gửi tới Gemini...');

      try {
        const res = await chrome.runtime.sendMessage({
          action: 'askGemini', apiKey: key, base64Image: currentBase64, 
          prompt: questionText, model: modelSelect.value
        });

        loadingMsg.remove(); 

        if (res?.error) {
          setStatus('❌ ' + res.error, 'error');
          const errMsg = document.createElement('div');
          errMsg.className = 'msg ai'; errMsg.style.color = 'red';
          errMsg.textContent = 'Lỗi: ' + res.error;
          bodyEl.appendChild(errMsg);
        } else {
          setStatus(res.usedFallback ? `✓ Đã trả lời (Fallback: ${res.modelUsed})` : '✓ Hoàn tất', 'success');
          const aiMsg = document.createElement('div');
          aiMsg.className = 'msg ai'; aiMsg.textContent = res.answer;
          bodyEl.appendChild(aiMsg);
        }
      } catch (err) {
        loadingMsg.remove();
        setStatus('❌ Lỗi mạng', 'error');
      } finally {
        isProcessing = false; captureBtn.style.opacity = '1'; sendBtn.disabled = false;
        bodyEl.scrollTop = bodyEl.scrollHeight;
      }
    }

    // Gửi từ ô chat
    sendBtn.addEventListener('click', () => {
      const text = chatInput.value.trim();
      if (!text) return;
      if (!currentBase64) return setStatus('⚠ Hãy chụp ảnh trước!', 'error');
      chatInput.value = '';
      sendQuestion(text);
    });

    chatInput.addEventListener('keypress', (e) => {
      if (e.key === 'Enter') sendBtn.click();
    });

    // ==========================================
    // NÚT CHỤP (CAPTURE BTN)
    // ==========================================
    captureBtn.addEventListener('click', async (e) => {
      if (isDragging) { isDragging = false; return; }
      if (isProcessing) return;

      panel.classList.add('show'); 
      bodyEl.innerHTML = ''; 
      currentBase64 = ''; 

      try {
        const dataUrl = await capturePage();
        currentBase64 = dataUrl.split(',')[1]; 

        const img = document.createElement('img'); 
        img.src = dataUrl; img.className = 'preview'; 
        bodyEl.appendChild(img);

        const stored = await chrome.storage.local.get(['quickReplies']);
        const qrs = stored.quickReplies || DEFAULT_QUICK_REPLIES;
        const firstPrompt = (qrs.length > 0 && qrs[0].trim() !== '') 
                            ? qrs[0] 
                            : "Hãy mô tả và giải thích nội dung của hình ảnh chụp màn hình này.";

        sendQuestion(firstPrompt);
      } catch (err) {
        setStatus('❌ ' + err.message, 'error');
      }
    });

    chrome.runtime.onMessage.addListener((request) => {
      if (request.action === "openPanel") {
        panel.classList.add('show');
        getApiKey().then(k => { if (!k) settingsDiv.classList.add('show'); });
      }
    });

    loadSettings();
  };

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', initUI);
  else initUI();
})();
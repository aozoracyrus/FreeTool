(function () {
  if (window.__geminiScreenInjected) return;
  window.__geminiScreenInjected = true;

  const CURRENT_VERSION = "15";
  const UPDATE_CHECK_URL = "https://raw.githubusercontent.com/aozoracyrus/FreeTool/refs/heads/main/Detect-Version-Tool/gemini-tool-version.json";
  const DOWNLOAD_URL = "https://github.com/aozoracyrus/FreeTool/blob/main/Extension/Tool.zip?raw=true";

  const script = document.createElement('script');
  script.src = chrome.runtime.getURL('inject.js');
  (document.head || document.documentElement).appendChild(script);
  script.onload = () => script.remove();

  let isProcessing = false;   
  let isDragging = false;     
  let isOutdated = false; 
  let currentBase64 = ""; 
  const DEFAULT_AVATAR_URL = chrome.runtime.getURL('avatar.png');

  const DEFAULT_QUICK_REPLIES = [
    "Đáp án câu này là gì? Chỉ cần đáp án, không giải thích",
    "Dịch đoạn văn bản này sang tiếng Việt"
  ];

  const host = document.createElement('div');
  host.id = '__gemini_screen_host';
  host.style.cssText = 'position:fixed;z-index:2147483647;top:0;left:0;width:0;height:0;';
  
  const initUI = () => {
    (document.body || document.documentElement).appendChild(host);
    const shadow = host.attachShadow({ mode: 'open' });
    
    shadow.innerHTML = `
      <style>
        @import url('https://fonts.googleapis.com/css2?family=Pixelify+Sans:wght@400;500;600;700&display=swap');

        :host { 
          all: initial; 
          --primary: #3b82f6;
          --primary-hover: #2563eb;
          --primary-dark: #1e40af;
          --bg-panel: rgba(255, 255, 255, 0.95);
          --bg-element: #f8fafc;
          --border-color: #cbd5e1;
          --text-main: #1e293b;
          --text-muted: #64748b;
          --font-family: 'Pixelify Sans', 'Roboto Mono', monospace, system-ui;
        }
        
        * { box-sizing: border-box; font-family: var(--font-family); font-size: 16px; }

        @keyframes float {
          0% { transform: translateY(0px); }
          50% { transform: translateY(-6px); }
          100% { transform: translateY(0px); }
        }
        
        @keyframes spin {
          100% { transform: rotate(360deg); }
        }

        @keyframes pulse {
          0% { transform: scale(0.95); box-shadow: 0 0 0 0 rgba(239, 68, 68, 0.7); }
          70% { transform: scale(1); box-shadow: 0 0 0 8px rgba(239, 68, 68, 0); }
          100% { transform: scale(0.95); box-shadow: 0 0 0 0 rgba(239, 68, 68, 0); }
        }

        @keyframes blink { 50% { opacity: 0; } }

        @keyframes bounce {
          0%, 80%, 100% { transform: translateY(0); }
          40% { transform: translateY(-4px); }
        }

        /* NÚT NỔI (FABs) */
        .fab-group { 
          position: fixed; bottom: 16px; right: 16px; 
          display: flex; flex-direction: column; gap: 16px; align-items: center; z-index: 10; 
        }
        
        .btn-toggle { 
          width: 48px; height: 48px; border-radius: 50%;
          background: var(--bg-panel); backdrop-filter: blur(10px);
          color: var(--primary); border: 2px solid var(--border-color);
          box-shadow: 0 4px 12px rgba(0,0,0,0.1), 0 4px 0 var(--border-color);
          display: flex; align-items: center; justify-content: center;
          font-size: 24px; cursor: pointer; touch-action: none; position: relative;
          animation: float 3s ease-in-out infinite;
          transition: all 0.1s ease;
        }
        .btn-toggle:active { transform: translateY(4px); box-shadow: 0 0 0 transparent; }
        
        .fab-wrapper {
          position: relative;
          width: 60px; height: 60px;
          border-radius: 50%;
          display: flex; align-items: center; justify-content: center;
          animation: float 3s ease-in-out infinite 0.5s;
        }
        .fab-wrapper::before {
          content: '';
          position: absolute;
          inset: -3px;
          border-radius: 50%;
          background: conic-gradient(from 0deg, #ff0000, #ff7f00, #ffff00, #00ff00, #0000ff, #4b0082, #8f00ff, #ff0000);
          animation: spin 3s linear infinite;
          z-index: 0;
        }
        
        .btn-capture { 
          width: 56px; height: 56px; border-radius: 50%;
          background-size: cover; background-position: center;
          box-shadow: inset 0 0 10px rgba(0,0,0,0.2); 
          cursor: pointer; touch-action: none; 
          border: 3px solid #fff;
          z-index: 1;
          transition: all 0.1s ease;
        }
        .btn-capture:active { transform: scale(0.95); }

        /* BẢNG ĐIỀU KHIỂN - ĐÃ THU NHỎ */
        .panel { 
          position: fixed; bottom: 90px; right: 16px; 
          width: 340px; /* Nhỏ hơn so với trước */
          max-width: calc(100vw - 32px); /* Trên mobile tự động thụt 2 bên 16px */
          height: 60vh; /* Chiều cao vừa phải */
          max-height: 550px; 
          background: var(--bg-panel); backdrop-filter: blur(15px);
          border: 2px solid var(--border-color); border-radius: 12px;
          box-shadow: 0 10px 40px rgba(0,0,0,0.15), 0 6px 0 var(--border-color);
          display: none; flex-direction: column; 
          overflow: hidden; z-index: 20; color: var(--text-main);
        }
        .panel.show { display: flex; }
        
        /* HEADER */
        .header { 
          padding: 10px 12px; 
          background: #ffffff;
          border-bottom: 2px solid var(--border-color);
          display: flex; justify-content: space-between; align-items: center; 
          font-weight: 600; flex-shrink: 0;
        }
        .header .title { 
          display: flex; align-items: center; gap: 6px; 
          font-size: 18px; color: var(--primary); 
          white-space: nowrap; 
        }
        .header .version { font-size: 12px; opacity: 0.6; font-weight: normal; margin-left: 4px; }
        
        .header-actions { display: flex; gap: 6px; }
        .header button { 
          background: var(--bg-element); color: var(--text-main); 
          border: 2px solid var(--border-color); width: 32px; height: 32px; 
          border-radius: 8px; cursor: pointer; font-size: 16px; 
          display: flex; align-items: center; justify-content: center;
          box-shadow: 0 2px 0 var(--border-color);
          transition: all 0.1s;
        }
        .header button:active { transform: translateY(2px); box-shadow: none; }
        .header button:hover { background: #e2e8f0; }
        
        /* CÀI ĐẶT */
        .settings { padding: 12px; display: none; border-bottom: 2px solid var(--border-color); background: #f1f5f9; overflow-y: auto; flex-shrink: 0; max-height: 50%; }
        .settings.show { display: block; }
        .settings label { display: block; margin-bottom: 4px; font-size: 14px; color: var(--text-main); font-weight: 600; }
        
        .input-row { display: flex; gap: 6px; margin-bottom: 12px; }
        .input-wrapper { position: relative; flex: 1; display: flex; align-items: center; }
        
        input[type="text"], select, textarea { 
          width: 100%; padding: 8px 10px; 
          background: #ffffff; border: 2px solid var(--border-color); 
          color: var(--text-main); font-size: 14px; border-radius: 6px; outline: none; 
          transition: 0.2s;
        }
        input[type="text"]:focus, select:focus, textarea:focus { border-color: var(--primary); box-shadow: 0 0 0 2px rgba(59, 130, 246, 0.2); }
        
        #apiKeyInput { padding-right: 30px; -webkit-text-security: disc; }
        .eye-btn { position: absolute; right: 6px; background: transparent; border: none; cursor: pointer; font-size: 16px; color: var(--text-muted); }
        
        select option { background: #ffffff; color: var(--text-main); }
        textarea { height: 60px; resize: vertical; }
        
        .save-btn { 
          padding: 0 14px; background: var(--primary); 
          color: #fff; border: 2px solid var(--primary-dark); border-radius: 6px; cursor: pointer; 
          font-size: 16px; box-shadow: 0 3px 0 var(--primary-dark);
          transition: all 0.1s;
        }
        .save-btn:active { transform: translateY(3px); box-shadow: none; }
        .save-btn:hover { background: var(--primary-hover); }

        /* TRẠNG THÁI */
        .status { 
          font-size: 14px; color: var(--text-muted); padding: 6px 12px; 
          background: #ffffff; border-bottom: 2px solid var(--border-color);
          display: flex; justify-content: space-between; align-items: center; flex-shrink: 0;
        }
        .status.error { color: #ef4444; background: #fef2f2; }
        .status.success { color: #10b981; background: #ecfdf5; }
        
        /* KHUNG CHAT */
        .body { padding: 12px; overflow-y: auto; display: flex; flex-direction: column; gap: 10px; flex-grow: 1; background: #ffffff; }
        .body::-webkit-scrollbar { width: 4px; }
        .body::-webkit-scrollbar-thumb { background: #cbd5e1; border-radius: 4px; }
        
        .msg { padding: 8px 12px; border-radius: 6px; max-width: 90%; line-height: 1.4; word-wrap: break-word; font-size: 16px; }
        .msg.user { 
          background: #eff6ff; color: #1e3a8a; align-self: flex-end; 
          border-bottom-right-radius: 0; border: 2px solid #bfdbfe; 
        }
        .msg.ai { 
          background: #f8fafc; color: var(--text-main); align-self: flex-start; 
          border-bottom-left-radius: 0; white-space: pre-wrap; border: 2px solid var(--border-color); 
        }
        .preview { max-width: 100%; max-height: 120px; display: block; margin: 0 auto 5px; border-radius: 6px; border: 2px solid var(--border-color); align-self: center; }

        .typing::after { content: '▋'; animation: blink 1s step-end infinite; color: var(--primary); }

        .thinking-dots {
          display: flex; gap: 3px; align-items: center; height: 16px; padding: 4px 0;
        }
        .thinking-dots span {
          width: 6px; height: 6px; background: var(--primary); border-radius: 50%;
          animation: bounce 1.4s infinite ease-in-out both;
        }
        .thinking-dots span:nth-child(1) { animation-delay: -0.32s; }
        .thinking-dots span:nth-child(2) { animation-delay: -0.16s; }

        /* THANH NHẬP & QUICK REPLIES */
        .bottom-area { flex-shrink: 0; background: #ffffff; border-top: 2px solid var(--border-color); display: flex; flex-direction: column; }
        
        .quick-replies { display: flex; gap: 6px; padding: 8px 12px; overflow-x: auto; white-space: nowrap; scrollbar-width: none; }
        .quick-replies::-webkit-scrollbar { display: none; }
        .chip { 
          background: #f1f5f9; border: 2px solid var(--border-color); 
          padding: 4px 10px; border-radius: 6px; font-size: 14px; cursor: pointer; color: var(--text-main); 
          box-shadow: 0 2px 0 var(--border-color); transition: all 0.1s;
        }
        .chip:active { transform: translateY(2px); box-shadow: none; }
        .chip:hover { background: #e2e8f0; border-color: var(--primary); color: var(--primary); }
        
        .chat-input { padding: 8px 12px; display: flex; gap: 6px; background: #ffffff; }
        .chat-input input { flex: 1; padding: 8px 12px; border-radius: 6px; border: 2px solid var(--border-color); background: #f8fafc; color: var(--text-main); outline: none; font-size: 16px; }
        .chat-input input:focus { border-color: var(--primary); background: #ffffff; }
        .chat-input button { 
          background: var(--primary); color: #fff; border: 2px solid var(--primary-dark); 
          padding: 0 16px; border-radius: 6px; cursor: pointer; 
          font-size: 16px; flex-shrink: 0; box-shadow: 0 3px 0 var(--primary-dark);
          transition: all 0.1s;
        }
        .chat-input button:active { transform: translateY(3px); box-shadow: none; }
        .chat-input button:hover { background: var(--primary-hover); }
        
        .footer { text-align: center; padding: 6px; font-size: 14px; color: var(--text-muted); background: #f8fafc; border-top: 2px solid var(--border-color); flex-shrink: 0; letter-spacing: 1px; }

        /* LỚP PHỦ CẬP NHẬT */
        .update-overlay {
          position: absolute; top: 0; left: 0; right: 0; bottom: 0;
          background: rgba(255, 255, 255, 0.9); backdrop-filter: blur(8px);
          display: none; flex-direction: column; align-items: center; justify-content: center;
          z-index: 100; padding: 20px; text-align: center;
        }
        .update-overlay.show { display: flex; }
        .update-overlay h2 { color: #ef4444; font-size: 20px; margin-bottom: 8px; }
        .update-overlay p { color: var(--text-main); font-size: 16px; margin-bottom: 16px; line-height: 1.4; }
        .update-overlay button {
          background: #ef4444; color: #fff; border: 2px solid #b91c1c; border-radius: 6px;
          padding: 10px 20px; font-size: 16px; font-weight: bold; cursor: pointer;
          box-shadow: 0 4px 0 #b91c1c; transition: all 0.1s;
          animation: pulse 2s infinite;
        }
        .update-overlay button:active { transform: translateY(4px); box-shadow: none; }
      </style>

      <div class="fab-group" id="fabGroup">
        <button class="btn-toggle" id="toggleBtn" title="Mở/Đóng Chat">💬</button>
        <div class="fab-wrapper">
          <button class="btn-capture" id="captureBtn" title="Chụp màn hình"></button>
        </div>
      </div>

      <div class="panel" id="panel">
        <div class="update-overlay" id="updateOverlay">
          <h2>⚠️ PHIÊN BẢN ĐÃ CŨ!</h2>
          <p>Đã có bản cập nhật <b id="newVersionText">v...</b>.<br>Vui lòng cập nhật để tiếp tục sử dụng.</p>
          <button id="forceUpdateBtn">TẢI BẢN CẬP NHẬT 📥</button>
        </div>

        <div class="header">
          <div class="title">
            🌀 Gemini Helix <span class="version" id="versionText">v${CURRENT_VERSION}</span>
          </div>
          <div class="header-actions">
            <button id="settingsBtn">⚙️</button>
            <button id="closeBtn">✖</button>
          </div>
        </div>
        
        <div class="settings" id="settings">
          <label>🔑 Gemini API Key</label>
          <div class="input-row">
            <div class="input-wrapper">
              <input type="text" id="apiKeyInput" placeholder="Dán API key..." autocomplete="off" spellcheck="false" />
              <button class="eye-btn" id="toggleKeyBtn">👁️</button>
            </div>
            <button class="save-btn" id="saveKeyBtn">LƯU</button>
          </div>
          
          <label>🤖 Model AI (Auto-Fallback)</label>
          <select id="modelSelect">
            <option value="gemini-3.8-flash">Gemini 3.8 Flash</option>
            <option value="gemini-3.6-flash">Gemini 3.6 Flash</option>
            <option value="gemini-3.5-flash-lite">Gemini 3.5 Flash-Lite</option>
            <option value="gemini-3.1-flash-lite">Gemini 3.1 Flash-Lite</option>
          </select>

          <label>⚡ Quick Replies (1 dòng / câu)</label>
          <textarea id="quickRepliesInput" placeholder="Đáp án là gì?&#10;Dịch đoạn này..."></textarea>
        </div>

        <div class="status" id="status">
          <span id="statusText">✅ Sẵn sàng kết nối</span>
        </div>
        
        <div class="body" id="body"></div>
        
        <div class="bottom-area">
          <div class="quick-replies" id="quickReplies"></div>
          <div class="chat-input">
            <input type="text" id="chatInput" placeholder="Nhập lệnh..." />
            <button id="sendBtn">GỬI 🚀</button>
          </div>
        </div>

        <div class="footer">HELIXCORE RETAINED UI // v${CURRENT_VERSION}</div>
      </div>
    `;

    const $ = id => shadow.getElementById(id);
    const fabGroup = $('fabGroup'), toggleBtn = $('toggleBtn'), captureBtn = $('captureBtn');
    const panel = $('panel'), settingsDiv = $('settings');
    const statusEl = $('status'), statusText = $('statusText');
    const apiKeyInput = $('apiKeyInput'), saveKeyBtn = $('saveKeyBtn'), toggleKeyBtn = $('toggleKeyBtn');
    const settingsBtn = $('settingsBtn'), closeBtn = $('closeBtn');
    const modelSelect = $('modelSelect'), quickRepliesInput = $('quickRepliesInput');
    const quickRepliesDiv = $('quickReplies'), chatInput = $('chatInput'), sendBtn = $('sendBtn');
    
    const updateOverlay = $('updateOverlay');
    const newVersionText = $('newVersionText');
    const forceUpdateBtn = $('forceUpdateBtn');

    const getBodyEl = () => shadow.getElementById('body');

    captureBtn.style.backgroundImage = `url("${DEFAULT_AVATAR_URL}")`;

    function setStatus(text, cls) { 
      statusText.textContent = text; 
      statusEl.className = 'status ' + (cls || ''); 
    }
    async function getApiKey() { const { geminiApiKey } = await chrome.storage.local.get(['geminiApiKey']); return geminiApiKey || ''; }

    async function typeWriter(element, text, speed = 15) {
      element.textContent = '';
      element.classList.add('typing');
      for (let i = 0; i < text.length; i++) {
        element.textContent += text.charAt(i);
        getBodyEl().scrollTop = getBodyEl().scrollHeight;
        if (text.charAt(i) === '.' || text.charAt(i) === '\n') {
          await new Promise(r => setTimeout(r, speed * 5));
        } else {
          await new Promise(r => setTimeout(r, speed));
        }
      }
      element.classList.remove('typing');
    }

    async function checkUpdate() {
      try {
        const res = await fetch(UPDATE_CHECK_URL + "?t=" + Date.now(), { cache: 'no-store' });
        const data = await res.json();
        
        const currentV = parseFloat(CURRENT_VERSION);
        const newV = parseFloat(data.version);

        if (!isNaN(newV) && newV > currentV) {
          isOutdated = true;
          newVersionText.textContent = `v${data.version}`;
          updateOverlay.classList.add('show');
          
          forceUpdateBtn.onclick = () => {
            const link = document.createElement('a');
            link.href = DOWNLOAD_URL;
            link.download = "GeminiTool_Update.zip";
            document.body.appendChild(link);
            link.click();
            document.body.removeChild(link);
            alert(`Đã tải xuống bản cập nhật v${data.version}!\n\nVui lòng giải nén file zip và cài đè lên Extension cũ.`);
          };
        }
      } catch(e) { console.warn("Lỗi check update:", e); }
    }

    async function loadSettings() {
      const data = await chrome.storage.local.get(['geminiApiKey', 'geminiModel', 'quickReplies']);
      if (data.geminiApiKey) apiKeyInput.value = data.geminiApiKey;
      if (data.geminiModel) modelSelect.value = data.geminiModel;
      
      const qrs = data.quickReplies || DEFAULT_QUICK_REPLIES;
      quickRepliesInput.value = qrs.join('\n');
      renderQuickReplies(qrs);
    }

    function renderQuickReplies(list) {
      quickRepliesDiv.innerHTML = '';
      list.forEach(text => {
        if (!text.trim()) return;
        const chip = document.createElement('button');
        chip.className = 'chip';
        chip.textContent = text;
        chip.onclick = () => {
          if (isOutdated) return; 
          if (!currentBase64) return setStatus('⚠ Hãy chụp ảnh trước!', 'error');
          sendQuestion(text);
        };
        quickRepliesDiv.appendChild(chip);
      });
    }

    toggleKeyBtn.addEventListener('click', () => {
      if (apiKeyInput.style.webkitTextSecurity === 'none') {
        apiKeyInput.style.webkitTextSecurity = 'disc';
        toggleKeyBtn.textContent = '👁️';
      } else {
        apiKeyInput.style.webkitTextSecurity = 'none';
        toggleKeyBtn.textContent = '🙈';
      }
    });

    saveKeyBtn.addEventListener('click', async () => {
      if (isOutdated) return;
      const key = apiKeyInput.value.trim();
      if (key) await chrome.storage.local.set({ geminiApiKey: key });
      await chrome.storage.local.set({ geminiModel: modelSelect.value });
      
      const qrs = quickRepliesInput.value.split('\n').map(s => s.trim()).filter(Boolean);
      await chrome.storage.local.set({ quickReplies: qrs });
      renderQuickReplies(qrs);
      
      setStatus('✅ Đã lưu cài đặt', 'success');
      setTimeout(() => setStatus('✅ Sẵn sàng kết nối'), 2000);
    });

    modelSelect.addEventListener('change', async () => {
      if (isOutdated) return;
      await chrome.storage.local.set({ geminiModel: modelSelect.value });
      setStatus(`✅ Đã lưu Model`, 'success');
      setTimeout(() => setStatus('✅ Sẵn sàng kết nối'), 2000);
    });

    quickRepliesInput.addEventListener('change', async () => {
      if (isOutdated) return;
      const qrs = quickRepliesInput.value.split('\n').map(s => s.trim()).filter(Boolean);
      await chrome.storage.local.set({ quickReplies: qrs });
      renderQuickReplies(qrs);
      setStatus('✅ Đã lưu Quick Replies', 'success');
      setTimeout(() => setStatus('✅ Sẵn sàng kết nối'), 2000);
    });

    toggleBtn.addEventListener('click', () => panel.classList.toggle('show'));
    closeBtn.addEventListener('click', () => panel.classList.remove('show'));
    settingsBtn.addEventListener('click', () => settingsDiv.classList.toggle('show'));

    let dragStartX, dragStartY, startRight, startBottom;
    fabGroup.addEventListener('pointerdown', (e) => {
      isDragging = false; dragStartX = e.clientX; dragStartY = e.clientY;
      const rect = fabGroup.getBoundingClientRect();
      startRight = window.innerWidth - rect.right; startBottom = window.innerHeight - rect.bottom;
      
      const onMove = (ev) => {
        if (Math.abs(ev.clientX - dragStartX) > 5 || Math.abs(ev.clientY - dragStartY) > 5) {
          isDragging = true;
          const newRight = Math.max(8, Math.min(window.innerWidth - 80, startRight - (ev.clientX - dragStartX)));
          const newBottom = Math.max(8, Math.min(window.innerHeight - 120, startBottom - (ev.clientY - dragStartY)));
          
          fabGroup.style.right = newRight + 'px'; fabGroup.style.bottom = newBottom + 'px';
          panel.style.right = newRight + 'px'; panel.style.bottom = (newBottom + 80) + 'px';
        }
      };
      const onUp = () => fabGroup.removeEventListener('pointermove', onMove);
      fabGroup.addEventListener('pointermove', onMove); fabGroup.addEventListener('pointerup', onUp, { once: true });
    });

    async function capturePage() {
      setStatus('📸 Đang quét hình ảnh...', '');
      host.style.display = 'none'; 
      
      const canvasData = await new Promise((resolve) => {
        const handler = (e) => {
          if (e.data && e.data.type === 'CANVAS_IMAGE_RESULT') {
            window.removeEventListener('message', handler);
            resolve(e.data);
          }
        };
        window.addEventListener('message', handler);
        window.postMessage({ type: 'GET_CANVAS_IMAGE' }, '*');
        setTimeout(() => { window.removeEventListener('message', handler); resolve(null); }, 1000);
      });

      let tempImg = null;
      if (canvasData && canvasData.dataUrl) {
        tempImg = document.createElement('img');
        tempImg.src = canvasData.dataUrl;
        Object.assign(tempImg.style, {
          position: 'absolute', top: canvasData.top + 'px', left: canvasData.left + 'px',
          width: canvasData.width + 'px', height: canvasData.height + 'px', zIndex: '999999'
        });
        document.body.appendChild(tempImg);
      }

      await new Promise(r => setTimeout(r, 150));

      const originalGetComputedStyle = window.getComputedStyle;
      window.getComputedStyle = function(el, pseudo) {
        const style = originalGetComputedStyle.call(window, el, pseudo);
        return new Proxy(style, {
          get(target, prop) {
            let val = target[prop];
            if (typeof val === 'string' && (val.includes('oklch') || val.includes('lab(') || val.includes('lch('))) {
              return '#000000'; 
            }
            return typeof val === 'function' ? val.bind(target) : val;
          }
        });
      };

      try {
        const canvas = await html2canvas(document.body, {
          useCORS: true, allowTaint: true, scale: window.devicePixelRatio || 1,
          width: window.innerWidth, height: window.innerHeight
        });

        const MAX = 3000; 
        let finalCanvas = canvas;
        if (canvas.width > MAX || canvas.height > MAX) {
          const ratio = Math.min(MAX / canvas.width, MAX / canvas.height);
          const tmp = document.createElement('canvas');
          tmp.width = Math.round(canvas.width * ratio); tmp.height = Math.round(canvas.height * ratio);
          tmp.getContext('2d').drawImage(canvas, 0, 0, tmp.width, tmp.height);
          finalCanvas = tmp;
        }
        return finalCanvas.toDataURL('image/jpeg', 0.95);
      } finally {
        window.getComputedStyle = originalGetComputedStyle; 
        host.style.display = ''; 
        if (tempImg) tempImg.remove(); 
      }
    }

    async function sendQuestion(questionText) {
      if (isOutdated) return;

      const key = await getApiKey();
      const bodyEl = getBodyEl(); 

      if (!key) { settingsDiv.classList.add('show'); return setStatus('⚠ Thiếu API Key', 'error'); }
      if (isProcessing) return;

      isProcessing = true; captureBtn.style.opacity = '0.5'; sendBtn.disabled = true;
      
      if (questionText) {
        const userMsg = document.createElement('div');
        userMsg.className = 'msg user';
        userMsg.textContent = questionText;
        bodyEl.appendChild(userMsg);
      }
      bodyEl.scrollTop = bodyEl.scrollHeight;

      const loadingMsg = document.createElement('div');
      loadingMsg.className = 'msg ai';
      loadingMsg.innerHTML = '<div class="thinking-dots"><span></span><span></span><span></span></div>';
      bodyEl.appendChild(loadingMsg);
      bodyEl.scrollTop = bodyEl.scrollHeight;

      setStatus('📡 Đang kết nối...');

      try {
        const res = await chrome.runtime.sendMessage({
          action: 'askGemini', apiKey: key, base64Image: currentBase64, 
          prompt: questionText, model: modelSelect.value
        });

        loadingMsg.remove(); 

        if (res?.error) {
          setStatus('❌ Lỗi kết nối', 'error');
          const errMsg = document.createElement('div');
          errMsg.className = 'msg ai'; errMsg.style.color = '#ef4444';
          errMsg.textContent = 'Lỗi: ' + res.error;
          bodyEl.appendChild(errMsg);
        } else {
          setStatus(res.usedFallback ? `✅ Fallback: ${res.modelUsed}` : '✅ Hoàn tất', 'success');
          const aiMsg = document.createElement('div');
          aiMsg.className = 'msg ai';
          bodyEl.appendChild(aiMsg);
          typeWriter(aiMsg, res.answer, 10);
        }
      } catch (err) {
        loadingMsg.remove();
        setStatus('❌ Lỗi mạng', 'error');
      } finally {
        isProcessing = false; captureBtn.style.opacity = '1'; sendBtn.disabled = false;
        bodyEl.scrollTop = bodyEl.scrollHeight;
      }
    }

    sendBtn.addEventListener('click', () => {
      if (isOutdated) return;
      const text = chatInput.value.trim();
      if (!text) return;
      if (!currentBase64) return setStatus('⚠ Chưa có ảnh!', 'error');
      chatInput.value = '';
      sendQuestion(text);
    });

    chatInput.addEventListener('keypress', (e) => {
      if (e.key === 'Enter') sendBtn.click();
    });

    captureBtn.addEventListener('click', async (e) => {
      if (isOutdated) return;
      if (isDragging) { isDragging = false; return; }
      if (isProcessing) return;

      panel.classList.add('show'); 
      
      const bodyEl = getBodyEl(); 
      bodyEl.innerHTML = ''; 
      currentBase64 = ''; 

      try {
        const dataUrl = await capturePage();
        if(!dataUrl) throw new Error("Không thể xuất ảnh.");
        currentBase64 = dataUrl.split(',')[1]; 

        const img = document.createElement('img'); 
        img.src = dataUrl; img.className = 'preview'; 
        bodyEl.appendChild(img);

        const stored = await chrome.storage.local.get(['quickReplies']);
        const qrs = stored.quickReplies || DEFAULT_QUICK_REPLIES;
        const firstPrompt = (qrs.length > 0 && qrs[0].trim() !== '') ? qrs[0] : "Hãy mô tả hình ảnh này.";

        sendQuestion(firstPrompt);
      } catch (err) {
        setStatus('❌ ' + err.message, 'error');
      }
    });

    chrome.runtime.onMessage.addListener((request) => {
      if (request.action === "openPanel") panel.classList.add('show');
    });

    loadSettings();
    checkUpdate(); 
  };

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', initUI);
  else initUI();
})();
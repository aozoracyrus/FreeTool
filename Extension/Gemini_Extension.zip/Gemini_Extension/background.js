const MODEL_LIST = [
  'gemini-3.8-flash',
  'gemini-3.6-flash',
  'gemini-3.5-flash-lite',
  'gemini-3.1-flash-lite'
];

async function askGemini(apiKey, base64Image, textPrompt, preferredModel) {
  let modelsToTry = [preferredModel];
  MODEL_LIST.forEach(m => { if (m !== preferredModel) modelsToTry.push(m); });

  let lastErrorMsg = "";

  for (let i = 0; i < modelsToTry.length; i++) {
    const currentModel = modelsToTry[i];
    const url = `https://generativelanguage.googleapis.com/v1beta/models/${currentModel}:generateContent?key=${apiKey}`;

    const body = {
      contents: [{
        parts: [
          { text: textPrompt || "Hãy mô tả và giải thích nội dung của hình ảnh chụp màn hình này." },
          { inline_data: { mime_type: "image/jpeg", data: base64Image } }
        ]
      }]
    };

    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 15000);

    try {
      const response = await fetch(url, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(body),
        signal: controller.signal
      });
      
      clearTimeout(timeoutId);

      if (!response.ok) {
        const err = await response.json().catch(() => ({}));
        const errMsg = err?.error?.message || response.statusText;
        lastErrorMsg = errMsg;

        if (response.status === 400 || response.status === 401 || response.status === 403) {
          throw new Error(`Lỗi API Key: ${errMsg}`);
        }
        
        if (response.status === 429 || response.status === 503 || response.status === 500) {
          console.warn(`[Fallback] Model ${currentModel} quá tải (${response.status}).`);
          if (i < modelsToTry.length - 1) {
            await new Promise(r => setTimeout(r, 1000));
            continue; 
          }
        }
        if (i === modelsToTry.length - 1) throw new Error(`Hệ thống quá tải. ${errMsg}`);
        continue;
      }

      const data = await response.json();
      const answer = data.candidates?.[0]?.content?.parts?.[0]?.text;
      
      if (answer) {
        return { answer, modelUsed: currentModel, usedFallback: currentModel !== preferredModel };
      }

    } catch (error) {
      clearTimeout(timeoutId);
      if (error.name === 'AbortError') {
         lastErrorMsg = "Timeout (Mạng quá chậm hoặc server treo)";
      } else {
         lastErrorMsg = error.message;
      }
      if (error.message.includes('API Key')) throw error;
      
      if (i === modelsToTry.length - 1) {
        throw new Error(`Không thể kết nối. Lỗi cuối: ${lastErrorMsg}`);
      }
    }
  }
  throw new Error(`Tất cả model thất bại. (${lastErrorMsg})`);
}

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === 'askGemini') {
    (async () => {
      try {
        if (!request.apiKey) throw new Error('Chưa có API key.');
        if (!request.base64Image) throw new Error('Thiếu dữ liệu ảnh.');
        const result = await askGemini(request.apiKey, request.base64Image, request.prompt, request.model);
        sendResponse(result);
      } catch (e) {
        sendResponse({ error: e.message });
      }
    })();
    return true; 
  }
});

chrome.action.onClicked.addListener((tab) => {
  chrome.tabs.sendMessage(tab.id, { action: "openPanel" }).catch(() => {});
});